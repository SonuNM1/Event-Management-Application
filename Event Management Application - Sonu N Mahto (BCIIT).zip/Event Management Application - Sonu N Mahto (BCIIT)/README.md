Event Management System is a platform for vendors to provide services realted to events and for users to to use that services to manage their event.


##***Project is under developoment phase.***



